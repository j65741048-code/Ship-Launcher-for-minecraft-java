package com.movtery.zalithlauncher.ui.view

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.util.AttributeSet
import android.view.Choreographer
import android.view.View
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

/**
 * Night sea with blocky 2D ships that sail across and sink.
 *
 * Performance notes:
 *  - one Paint, no allocations inside onDraw / frame callback
 *  - capped at ~30 FPS
 *  - the frame loop only runs while the view is attached AND visible; it stops
 *    completely when the launcher is in the background or the game is running
 */
class ShipsBackgroundView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr), Choreographer.FrameCallback {

    private class Ship {
        var state = 0            // 0 waiting, 1 sailing, 2 sinking
        var x = 0f               // centre, in blocks
        var dir = 1f
        var speed = 5f
        var scale = 1f
        var sinkX = 0f
        var survives = false
        var timer = 0f
        var tilt = 0f
        var tiltDir = 1f
        var drop = 0f            // blocks below the surface
        var palette = 0
    }

    private val rnd = Random(System.nanoTime())
    private val ships = Array(4) { i -> Ship().also { it.timer = i * 2.5f } }
    private val paint = Paint().apply { isAntiAlias = false; style = Paint.Style.FILL }

    private val starX = FloatArray(40) { rnd.nextFloat() }
    private val starY = FloatArray(40) { rnd.nextFloat() }
    private val starP = FloatArray(40) { rnd.nextFloat() * 6.28f }

    private val bubX = FloatArray(40)
    private val bubY = FloatArray(40)
    private val bubLife = FloatArray(40)
    private var bubIndex = 0

    private var time = 0f
    private var wBlocks = 60f
    private var b = 1f           // block size in px
    private var seaY = 0f
    private var skyShader: Shader? = null
    private var seaShader: Shader? = null

    private var running = false
    private var lastNanos = 0L
    private var accum = 0f

    // ---------------------------------------------------------------- lifecycle

    private fun shouldRun() = isAttachedToWindow && windowVisibility == VISIBLE && visibility == VISIBLE

    private fun refreshRunning() {
        if (shouldRun()) {
            if (!running) {
                running = true
                lastNanos = 0L
                Choreographer.getInstance().postFrameCallback(this)
            }
        } else if (running) {
            running = false
            Choreographer.getInstance().removeFrameCallback(this)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        refreshRunning()
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        refreshRunning()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        refreshRunning()
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        refreshRunning()
    }

    // ---------------------------------------------------------------- simulation

    override fun doFrame(frameTimeNanos: Long) {
        if (!running) return
        if (lastNanos == 0L) lastNanos = frameTimeNanos
        val dt = (frameTimeNanos - lastNanos) / 1_000_000_000f
        accum += dt
        lastNanos = frameTimeNanos
        if (accum >= FRAME_STEP) {
            update(min(accum, 0.1f))
            accum = 0f
            invalidate()
        }
        Choreographer.getInstance().postFrameCallback(this)
    }

    private fun addBubble(x: Float, y: Float) {
        bubX[bubIndex] = x
        bubY[bubIndex] = y
        bubLife[bubIndex] = 1.5f + rnd.nextFloat()
        bubIndex = (bubIndex + 1) % bubX.size
    }

    private fun spawn(s: Ship) {
        s.dir = if (rnd.nextBoolean()) 1f else -1f
        s.scale = SCALES[rnd.nextInt(SCALES.size)]
        s.speed = 3.5f + rnd.nextFloat() * 3f
        s.x = if (s.dir > 0f) -9f else wBlocks + 9f
        s.survives = rnd.nextFloat() < 0.25f
        s.sinkX = wBlocks * (0.2f + rnd.nextFloat() * 0.6f)
        s.palette = rnd.nextInt(PALETTES.size)
        s.tilt = 0f
        s.drop = 0f
        s.state = 1
    }

    private fun update(dt: Float) {
        time += dt
        for (s in ships) {
            when (s.state) {
                0 -> {
                    s.timer -= dt
                    if (s.timer <= 0f) spawn(s)
                }
                1 -> {
                    s.x += s.dir * s.speed * dt
                    val hit = !s.survives &&
                        ((s.dir > 0f && s.x >= s.sinkX) || (s.dir < 0f && s.x <= s.sinkX))
                    if (hit) {
                        s.state = 2
                        s.timer = 0f
                        s.tiltDir = if (rnd.nextBoolean()) 1f else -1f
                    } else if (s.x < -10f || s.x > wBlocks + 10f) {
                        s.state = 0
                        s.timer = 1f + rnd.nextFloat() * 3f
                    }
                }
                else -> {
                    s.timer += dt
                    s.tilt = (s.tilt + s.tiltDir * (8f + s.timer * 6f) * dt).coerceIn(-85f, 85f)
                    s.drop += (1.2f + s.timer * 1.1f) * dt
                    s.x += s.dir * s.speed * 0.15f * dt
                    if (rnd.nextFloat() < dt * 14f) {
                        addBubble(s.x + (rnd.nextFloat() - 0.5f) * 4f * s.scale, -s.drop + 1f)
                    }
                    if (s.drop > 16f) {
                        s.state = 0
                        s.timer = 1f + rnd.nextFloat() * 3f
                        s.tilt = 0f
                        s.drop = 0f
                    }
                }
            }
        }
        for (i in bubLife.indices) {
            if (bubLife[i] > 0f) {
                bubLife[i] -= dt
                bubY[i] += 3f * dt
                bubX[i] += sin(time * 3f + i) * 0.4f * dt
                if (bubY[i] > 0f) bubLife[i] = 0f
            }
        }
    }

    // ---------------------------------------------------------------- drawing

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w <= 0 || h <= 0) return
        b = h / 30f
        seaY = h * 0.6f
        wBlocks = w / b
        skyShader = LinearGradient(
            0f, 0f, 0f, seaY,
            intArrayOf(0xFF070B24.toInt(), 0xFF16345A.toInt(), 0xFF3A6B8C.toInt()),
            null, Shader.TileMode.CLAMP
        )
        seaShader = LinearGradient(
            0f, seaY, 0f, h.toFloat(),
            intArrayOf(0xFF1E5F86.toInt(), 0xFF0B2A45.toInt(), 0xFF06182B.toInt()),
            null, Shader.TileMode.CLAMP
        )
    }

    private fun rect(c: Canvas, x: Float, y: Float, w: Float, h: Float, color: Int) {
        paint.shader = null
        paint.color = color
        c.drawRect(x, y, x + w, y + h, paint)
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        // sky
        paint.shader = skyShader
        canvas.drawRect(0f, 0f, w, seaY, paint)

        // stars
        for (i in starX.indices) {
            val a = (255 * (0.4f + 0.6f * abs(sin(time * 0.8f + starP[i])))).toInt()
            rect(canvas, starX[i] * w, starY[i] * seaY * 0.7f, b * 0.3f, b * 0.3f, (a shl 24) or 0xFFFFFF)
        }

        // moon
        val mx = w * 0.82f
        val my = h * 0.17f
        val mu = b * 0.6f
        for (r in MOON_ROWS.indices) {
            val hw = MOON_ROWS[r]
            rect(canvas, mx - hw * mu, my + (r - 3) * mu, 2 * hw * mu, mu, 0xFFF3EFD2.toInt())
        }

        // sea
        paint.shader = seaShader
        canvas.drawRect(0f, seaY, w, h, paint)

        val cols = (w / b).toInt() + 2
        for (i in 0 until cols) {
            val k = (sin(i * 0.55f + time * 1.4f) * 1.4f).roundToInt()
            rect(canvas, i * b, seaY + k * b * 0.5f - b * 0.5f, b, b * 0.5f, 0x55BFE3F2)
        }

        // ships
        for (s in ships) if (s.state != 0) drawShip(canvas, s)

        // front water layer (ships sink behind it)
        val front = seaY + b * 0.3f
        rect(canvas, 0f, front, w, h - front, 0x88104A6E.toInt())
        for (i in 0 until cols) {
            val k = (sin(i * 0.6f - time * 1.7f + 1.3f) * 1.4f).roundToInt()
            rect(canvas, i * b, front + k * b * 0.5f - b * 0.5f, b, b * 0.5f, 0x99D8F1FA.toInt())
        }

        // bubbles
        for (i in bubLife.indices) {
            if (bubLife[i] > 0f) {
                rect(canvas, bubX[i] * b, seaY - bubY[i] * b, b * 0.3f, b * 0.3f, 0xAAE8F8FF.toInt())
            }
        }
    }

    private fun drawShip(canvas: Canvas, s: Ship) {
        val bs = b * s.scale
        val cx = s.x * b
        val baseY = seaY + bs * 1.2f + s.drop * b
        val pal = PALETTES[s.palette]
        canvas.save()
        canvas.rotate(s.tilt, cx, baseY - bs * 2f)
        for (r in SHIP) {
            val x0 = if (s.dir > 0f) r[0] else 11 - r[0] - r[2]
            val color = when (r[4]) {
                0 -> pal[0]
                1 -> pal[1]
                2 -> pal[2]
                3 -> pal[3]
                else -> 0x22000000
            }
            rect(
                canvas,
                cx + (x0 - 5.5f) * bs,
                baseY - (r[1] + r[3]) * bs,
                r[2] * bs + 0.5f,
                r[3] * bs + 0.5f,
                color
            )
        }
        canvas.restore()
    }

    private companion object {
        const val FRAME_STEP = 1f / 30f
        val SCALES = floatArrayOf(0.6f, 0.8f, 1f)
        val MOON_ROWS = intArrayOf(1, 2, 3, 3, 3, 2, 1)

        val PALETTES = arrayOf(
            intArrayOf(0xFF5B3A1E.toInt(), 0xFF8B5A2B.toInt(), 0xFFEDE6D3.toInt(), 0xFFC0392B.toInt()),
            intArrayOf(0xFF3E2A1A.toInt(), 0xFF6F4E37.toInt(), 0xFFD9D2C0.toInt(), 0xFF2E86C1.toInt()),
            intArrayOf(0xFF4A3B2A.toInt(), 0xFF9C6B3A.toInt(), 0xFFF4EBD0.toInt(), 0xFFF1C40F.toInt())
        )

        // x, y(up), width, height, colour index (0 wood, 1 deck, 2 sail, 3 flag, 4 shade)
        val SHIP = arrayOf(
            intArrayOf(2, 0, 7, 1, 0),
            intArrayOf(1, 1, 9, 1, 0),
            intArrayOf(0, 2, 11, 1, 1),
            intArrayOf(0, 3, 2, 1, 0),
            intArrayOf(10, 3, 1, 2, 0),
            intArrayOf(2, 4, 7, 7, 2),
            intArrayOf(2, 7, 7, 1, 4),
            intArrayOf(5, 3, 1, 10, 0),
            intArrayOf(1, 11, 9, 1, 1),
            intArrayOf(6, 12, 3, 1, 3)
        )
    }
}
