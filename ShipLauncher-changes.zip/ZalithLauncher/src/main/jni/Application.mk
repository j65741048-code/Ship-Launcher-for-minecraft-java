# NDK_TOOLCHAIN_VERSION := 4.9
APP_PLATFORM := android-21
APP_STL := system
# APP_ABI := armeabi-v7a arm64-v8a x86 x86_64
# Optimised native code even for debug-type builds
APP_OPTIM := release
